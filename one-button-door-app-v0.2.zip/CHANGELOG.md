## v0.2
- MVP with map, GPS, reverse geocode, one-tap save
- Switched to CORS-safe text/plain POST
- Added config.json boot flow
